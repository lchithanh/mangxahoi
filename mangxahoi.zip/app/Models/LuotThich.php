<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LuotThich extends Model
{
    use HasFactory;

    protected $table = 'luotthich';
    protected $primaryKey = 'luot_thich_id';
    public $timestamps = false; // Nếu không có created_at, updated_at

    protected $fillable = [
        'luot_thich_id',
        'bai_viet_id',
        'nguoi_dung_id',
        'ngay_thich',
    ];

    public function baiviet()
    {
        return $this->belongsTo(BaiViet::class, 'bai_viet_id');
    }

    public function nguoidung()
    {
        return $this->belongsTo(NguoiDung::class, 'nguoi_dung_id');
    }
}
