<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ThongBao extends Model
{
    protected $table = 'thongbao';
    protected $primaryKey = 'thong_bao_id';
    public $timestamps = false;

    protected $fillable = [
        'nguoi_dung_id',
        'nguoi_gui_id',
        'loai_thong_bao',
        'noi_dung',
        'link',
        'da_xem',
        'thoi_gian'
    ];

    // ✨ Chuyển thoi_gian sang Carbon
    protected $casts = [
        'thoi_gian' => 'datetime',
    ];
}
