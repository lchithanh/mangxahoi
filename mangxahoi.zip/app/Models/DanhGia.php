<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhGia extends Model
{
    use HasFactory;

    protected $table = 'danhgia'; // tên bảng
    protected $primaryKey = 'danh_gia_id'; // khoá chính
    public $timestamps = false; // nếu bảng không có created_at/updated_at

    protected $fillable = [
        'bai_viet_id',
        'nguoi_dung_id',
        'so_sao',
    ];

    /* ===== Quan hệ với bài viết ===== */
    public function baiViet()
    {
        return $this->belongsTo(BaiViet::class, 'bai_viet_id', 'bai_viet_id');
    }

    /* ===== Quan hệ với người dùng ===== */
    public function nguoiDung()
    {
        return $this->belongsTo(NguoiDung::class, 'nguoi_dung_id', 'nguoi_dung_id');
    }
}
