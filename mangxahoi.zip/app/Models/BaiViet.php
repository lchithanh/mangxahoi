<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BaiViet extends Model
{
    use HasFactory;

    protected $table = 'baiviet';
    protected $primaryKey = 'bai_viet_id';

    protected $fillable = [
        'nguoi_dung_id',
        'noi_dung',
        'duong_dan_hinh_anh',
        'id_chu_de',
        'danh_gia',
    ];

    public function nguoidung()
    {
        return $this->belongsTo(NguoiDung::class, 'nguoi_dung_id');
    }

    public function luotThich()
    {
        return $this->hasMany(LuotThich::class, 'bai_viet_id');
    }

    public function binhLuan()
    {
        return $this->hasMany(BinhLuan::class, 'bai_viet_id')
                     ->where('trang_thai', 'hien_thi');
    }

    public function diaDiem()
    {
        return $this->hasOne(DiaDiem::class, 'bai_viet_id', 'bai_viet_id');
    }

    public function luuBaiViet()
    {
        return $this->hasMany(LuuBaiViet::class, 'bai_viet_id', 'bai_viet_id');
    }

    public function chude()
    {
        return $this->belongsTo(ChuDe::class, 'id_chu_de', 'id_chu_de');
    }
    public function danhGias()
{
    return $this->hasMany(DanhGia::class, 'bai_viet_id', 'bai_viet_id');
}


}
