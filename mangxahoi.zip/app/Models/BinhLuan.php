<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BinhLuan extends Model
{
    use HasFactory;

    protected $table = 'binhluan';
    protected $primaryKey = 'binh_luan_id';
    public $timestamps = false;

    protected $fillable = [
        'bai_viet_id',
        'nguoi_dung_id',
        'binh_luan_cha_id',
        'noi_dung',
        'trang_thai',
        'ngay_tao', // chỉ tên cột
    ];

    // Cast ngày giờ
    protected $casts = [
        'ngay_tao' => 'datetime',
    ];

    public function baiviet()
    {
        return $this->belongsTo(BaiViet::class, 'bai_viet_id');
    }

    public function nguoidung()
    {
        return $this->belongsTo(NguoiDung::class, 'nguoi_dung_id', 'nguoi_dung_id');
    }

    // Reply đệ quy vô hạn
    public function replies()
    {
        return $this->hasMany(BinhLuan::class, 'binh_luan_cha_id', 'binh_luan_id')
            ->where('trang_thai', 'hien_thi')
            ->with(['replies', 'nguoidung']);
    }
}


