<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NguoiDung extends Model
{
    use HasFactory;

    protected $table = 'nguoidung';
    protected $primaryKey = 'nguoi_dung_id';
    public $timestamps = false; // nếu bảng không có created_at, updated_at

    // Các trường có thể mass-assign (dùng khi create/update)
    protected $fillable = [
        'ten_dang_nhap',
        'email',
        'mat_khau_ma_hoa',
        'ho_va_ten',
        'anh_dai_dien',
        'ngay_sinh',
        'dia_chi',
        'sdt',
        'trang_thai',
        'ngay_dang_ky',
    ];

    // Trường cần ẩn khi trả về JSON
    protected $hidden = [
        'mat_khau_ma_hoa',
    ];

    // Quan hệ với bài viết
    public function baiviets()
    {
        return $this->hasMany(BaiViet::class, 'nguoi_dung_id');
    }

    // Laravel mặc định dùng cột 'password', ta đổi lại
    public function getAuthPassword()
    {
        return $this->mat_khau_ma_hoa;
    }

    // Kiểm tra hồ sơ đã hoàn thiện chưa
    public function daHoanThienHoSo()
    {
        return $this->ho_va_ten && $this->anh_dai_dien;
    }
    public function danhGias()
{
    return $this->hasMany(DanhGia::class, 'nguoi_dung_id', 'nguoi_dung_id');
}

}
