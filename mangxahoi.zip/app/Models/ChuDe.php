<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChuDe extends Model
{
    use HasFactory;

    protected $table = 'chude';
    protected $primaryKey = 'id_chu_de';
    protected $fillable = ['ten_chude'];

        public $timestamps = false;

    public function baiviets()
    {
        return $this->hasMany(BaiViet::class, 'id_chu_de', 'id_chu_de');
    }
    
}
