<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LuuBaiViet extends Model
{
    use HasFactory;

    protected $table = 'luubaiviet';
    protected $primaryKey = 'id_luu';
    public $timestamps = false; // Nếu không có created_at, updated_at

 protected $fillable = ['nguoi_dung_id', 'bai_viet_id', 'ngay_luu'];


    public function baiviet()
    {
        return $this->belongsTo(BaiViet::class, 'bai_viet_id');
    }
}
