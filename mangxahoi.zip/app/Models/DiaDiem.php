<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DiaDiem extends Model
{
    use HasFactory;

    protected $table = 'diadiem';
    protected $primaryKey = 'id_dia_diem';
    protected $fillable = [
        'ten_dia_diem',
        'dia_chi',
        'hinh_anh',
        'chu_de',
        'diem_trung_binh',
        'bai_viet_id',
    ];
        public $timestamps = false; // <-- quan trọng: tắt created_at / updated_at


    // Liên kết về bài viết
    public function baiViet()
    {
        return $this->belongsTo(BaiViet::class, 'bai_viet_id', 'bai_viet_id');
    }
    
}
