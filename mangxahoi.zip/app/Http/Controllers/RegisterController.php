<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\NguoiDung;
use Carbon\Carbon;

class RegisterController extends Controller
{
    // Hiển thị form đăng ký
    public function showRegisterForm() {
        return view('register');
    }

    // Xử lý đăng ký
    public function register(Request $request) {
        $request->validate([
            'ten_dang_nhap' => 'required|unique:nguoidung,ten_dang_nhap',
            'mat_khau' => 'required|min:3',
            'email' => 'required|email|unique:nguoidung,email',
            'ho_va_ten' => 'required',
            'ngay_sinh' => 'nullable|date',
            'dia_chi' => 'nullable|string|max:255',
            'sdt' => 'nullable|string|max:20',
        ]);

        $nguoiDung = NguoiDung::create([
            'ten_dang_nhap' => $request->ten_dang_nhap,
            'mat_khau_ma_hoa' => Hash::make($request->mat_khau),
            'email' => $request->email,
            'ho_va_ten' => $request->ho_va_ten,
            'ngay_sinh' => $request->ngay_sinh,
            'dia_chi' => $request->dia_chi,
            'sdt' => $request->sdt,
            'ngay_dang_ky' => Carbon::now(),
            'trang_thai' => 'hoat_dong'
        ]);

        // Lưu session
        session(['nguoi_dung_id' => $nguoiDung->nguoi_dung_id]);

        return redirect()->route('profile.setup');
    }
}
