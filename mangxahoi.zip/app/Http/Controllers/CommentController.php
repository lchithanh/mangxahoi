<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BinhLuan;
use App\Models\BaiViet;
use App\Models\NguoiDung;
use App\Http\Controllers\Notification; // Import Notification controller
use Illuminate\Support\Facades\Session;

class CommentController extends Controller
{
    /**
     * Lưu comment hoặc reply
     */
    public function store(Request $request, $postId)
    {
        $request->validate([
            'noi_dung' => 'required|string',
        ]);

        $userId = Session::get('nguoi_dung_id');
        if (!$userId) {
            return response()->json(['error' => 'Chưa đăng nhập!'], 401);
        }

        // Tạo comment mới
        $comment = BinhLuan::create([
            'bai_viet_id' => $postId,
            'nguoi_dung_id' => $userId,
            'binh_luan_cha_id' => $request->binh_luan_cha_id ?? null,
            'noi_dung' => $request->noi_dung,
            'trang_thai' => 'hien_thi',
            'ngay_tao' => now(),
        ]);

        $user = NguoiDung::find($userId);
        $userName = $user ? $user->ho_va_ten : 'Người dùng';

        // Tạo thông báo nếu comment bài của người khác
        $post = BaiViet::find($postId);
        if ($post && $post->nguoi_dung_id != $userId) {
            Notification::createNotification(
                $post->nguoi_dung_id, // người nhận
                $userId,              // người comment
                'comment',            // loại thông báo
                "{$userName} đã bình luận trên bài viết của bạn.", // nội dung
                url('/posts/' . $postId) // link tới bài viết
            );
        }

        return response()->json([
            'binh_luan_id' => $comment->binh_luan_id,
            'ho_va_ten' => $userName,
            'noi_dung' => $comment->noi_dung,
            'nguoi_dung_id' => $userId,
            'ngay_tao' => $comment->ngay_tao->format('Y-m-d H:i'),
            'parent_id' => $comment->binh_luan_cha_id,
        ]);
    }

    /**
     * Lấy danh sách comment + reply của một bài viết
     */
    public function listComments($postId)
    {
        $comments = BinhLuan::with(['nguoidung', 'replies'])
            ->where('bai_viet_id', $postId)
            ->whereNull('binh_luan_cha_id')
            ->where('trang_thai', 'hien_thi')
            ->orderByDesc('ngay_tao')
            ->get();

        return response()->json($comments);
    }

    /**
     * Cập nhật comment
     */
    public function update(Request $request, $id)
    {
        $request->validate(['noi_dung' => 'required|string']);

        $comment = BinhLuan::find($id);
        if (!$comment) {
            return response()->json(['success' => false, 'error' => 'Bình luận không tồn tại']);
        }

        $userId = Session::get('nguoi_dung_id');
        if ($comment->nguoi_dung_id != $userId) {
            return response()->json(['success' => false, 'error' => 'Bạn không có quyền sửa bình luận']);
        }

        $comment->noi_dung = $request->noi_dung;
        $comment->save();

        return response()->json([
            'success' => true,
            'noi_dung' => $comment->noi_dung,
            'binh_luan_id' => $comment->binh_luan_id,
        ]);
    }
    /**
 * Xóa bình luận
 */
public function destroy($id)
{
    $comment = BinhLuan::find($id);
    if (!$comment) {
        return response()->json(['success' => false, 'error' => 'Bình luận không tồn tại']);
    }

    $userId = Session::get('nguoi_dung_id');
    if ($comment->nguoi_dung_id != $userId) {
        return response()->json(['success' => false, 'error' => 'Bạn không có quyền xóa bình luận']);
    }

    // Nếu comment có reply, có thể xóa toàn bộ reply hoặc set trạng thái
    // 1. Xóa toàn bộ reply
    BinhLuan::where('binh_luan_cha_id', $comment->binh_luan_id)->delete();

    // 2. Xóa comment chính
    $comment->delete();

    return response()->json([
        'success' => true,
        'message' => 'Bình luận đã được xóa'
    ]);
}

}
