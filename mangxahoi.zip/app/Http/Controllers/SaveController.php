<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BaiViet;
use App\Models\LuuBaiViet;

class SaveController extends Controller
{
    // Trang bài viết đã lưu (Saved Posts)
    public function index()
    {
        $currentUserId = session('nguoi_dung_id');

        $luuBaiViets = BaiViet::whereHas('luuBaiViet', function($q) use ($currentUserId) {
                $q->where('nguoi_dung_id', $currentUserId);
            })
            ->with(['nguoidung', 'luotThich', 'binhLuan', 'diaDiem', 'luuBaiViet'])
            ->orderByDesc('created_at')
            ->paginate(10);

        return view('save.danhsach-luu', [
            'luuBaiViets' => $luuBaiViets,
            'currentUserId' => $currentUserId
        ]);
    }

    // Toggle lưu/hủy lưu từ trang Home hoặc trang Post
    public function toggle($id)
    {
        $userId = session('nguoi_dung_id');

        if (!$userId) {
            return response()->json(['error' => 'Cần đăng nhập'], 403);
        }

        $saved = LuuBaiViet::where('bai_viet_id', $id)
                            ->where('nguoi_dung_id', $userId)
                            ->first();

        if ($saved) {
            $saved->delete();
            return response()->json(['saved' => false, 'message' => 'Đã hủy lưu']);
        }

        LuuBaiViet::create([
            'bai_viet_id'   => $id,
            'nguoi_dung_id' => $userId,
            'ngay_luu'      => now()
        ]);

        return response()->json(['saved' => true, 'message' => 'Đã lưu bài viết!']);
    }

    // Hủy lưu từ trang Saved (DELETE)
    public function destroy($id)
    {
        $userId = session('nguoi_dung_id');

        LuuBaiViet::where('bai_viet_id', $id)
                  ->where('nguoi_dung_id', $userId)
                  ->delete();

        return response()->json(['success' => true]);
    }
}
