<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ThongBao;
use Illuminate\Support\Facades\Log;

class Notification extends Controller
{
    public function index()
    {
        $userId = session('nguoi_dung_id'); // hoặc auth()->id()
        $thongbaos = ThongBao::where('nguoi_dung_id', $userId)
                        ->orderByDesc('thoi_gian')
                        ->get();

        return view('thongbao.danhsach-thongbao', compact('thongbaos'));
    }

    public function markAsRead($id)
    {
        $tb = ThongBao::findOrFail($id);
        $tb->da_xem = 1;
        $tb->save();

        return response()->json([
            'success' => true,
            'redirect' => route('posts.show', ['id' => $tb->post_id])
        ]);
    }

    /**
     * Tạo thông báo mà không làm chết request nếu lỗi
     */
    public static function createNotification($nguoiDungId, $nguoiGuiId, $loai, $noiDung, $link = null)
    {
        try {
            ThongBao::create([
                'nguoi_dung_id' => $nguoiDungId,
                'nguoi_gui_id' => $nguoiGuiId,
                'loai_thong_bao' => $loai,
                'noi_dung' => $noiDung,
                'link' => $link,
                'da_xem' => 0,
                'thoi_gian' => now()
            ]);
        } catch (\Throwable $e) {
            // Ghi log lỗi nhưng không trả về client
            Log::error("Lỗi tạo Notification: " . $e->getMessage());
        }
    }
}
