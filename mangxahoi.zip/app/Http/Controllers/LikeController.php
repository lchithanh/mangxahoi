<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BaiViet;
use App\Models\LuotThich;
use App\Http\Controllers\Notification; // Đổi tên controller Notification
use App\Models\NguoiDung;

class LikeController extends Controller
{
    public function toggle($id)
    {
        $userId = session('nguoi_dung_id'); // hoặc auth()->id()

        if (!$userId) {
            return response()->json(['error' => 'Vui lòng đăng nhập để thích bài viết'], 403);
        }

        $post = BaiViet::findOrFail($id);

        $like = LuotThich::where('bai_viet_id', $id)
                         ->where('nguoi_dung_id', $userId)
                         ->first();

        if ($like) {
            // Unlike
            $like->delete();
            $liked = false;
        } else {
            // Like
            LuotThich::create([
                'bai_viet_id' => $id,
                'nguoi_dung_id' => $userId,
                'ngay_thich' => now()
            ]);
            $liked = true;

            // Lấy thông tin người thực hiện like
            $user = NguoiDung::find($userId);
            $userName = $user ? $user->ho_va_ten : 'Người dùng';
            
            
            // Tạo thông báo nếu like bài của người khác
            if ($post->nguoi_dung_id != $userId) {
                Notification::createNotification(
                    $post->nguoi_dung_id, // người nhận
                    $userId,              // người thực hiện like
                    'like',               // loại thông báo
        "{$userName} đã thích bài viết của bạn.", // nội dung hiển thị tên người dùng
                    url('/posts/' . $post->bai_viet_id) // link bài viết
                );
            }
        }

        $likeCount = LuotThich::where('bai_viet_id', $id)->count();

        return response()->json([
            'liked' => $liked,
            'count' => $likeCount
        ]);
    }

    public function getLikers($postId)
    {
        $post = BaiViet::with('luotThich.nguoiDung')->findOrFail($postId);

        $likers = $post->luotThich->map(function($like){
            return [
                'name' => $like->nguoiDung->ho_va_ten ?? 'Khách',
                'avatar' => $like->nguoiDung->anh_dai_dien
            ];
        });

        return response()->json($likers);
    }
}
