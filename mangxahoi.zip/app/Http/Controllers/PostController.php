<?php

namespace App\Http\Controllers;

use App\Models\DanhGia;
use Illuminate\Http\Request;
use App\Models\BaiViet;
use App\Models\ChuDe;
use App\Models\DiaDiem;

class PostController extends Controller
{
    // TRANG CHỦ – danh sách bài viết
    public function index()
    {
        $baiviets = BaiViet::with(['nguoidung','diaDiem','chude'])
                    ->orderByDesc('created_at')
                    ->get();

        return view('home', compact('baiviets'));
    }

    // FORM TẠO BÀI VIẾT
    public function create()
    {
        $chudes = ChuDe::all();
        return view('baiviet.tao-baiviet', compact('chudes'));
    }

    // LƯU BÀI VIẾT
    public function store(Request $request)
    {
        if (!session()->has('nguoi_dung_id')) {
            return back()->with('error', 'Vui lòng đăng nhập hoặc đăng ký để đăng bài.');
        }
        

        $request->validate([
            'noi_dung' => 'required|string',
            'id_chu_de' => 'nullable|exists:chude,id_chu_de',
            'ten_chude_moi' => 'nullable|string|max:255',
            'duong_dan_hinh_anh' => 'nullable|file|mimes:jpg,jpeg,png,mp4|max:20480',
            'danh_gia' => 'nullable|integer|min:0|max:5',
            'ten_dia_diem' => 'nullable|string|max:255',
            'dia_chi' => 'nullable|string|max:255',
        ]);

        $userId = session('nguoi_dung_id');
        $path = null;

        // Upload hình
        if ($request->hasFile('duong_dan_hinh_anh')) {
            $file = $request->file('duong_dan_hinh_anh');
            $fileName = time().'_'.preg_replace('/\s+/', '_', $file->getClientOriginalName());
            $uploadPath = public_path('uploads');
            if (!file_exists($uploadPath)) mkdir($uploadPath, 0755, true);

            $file->move($uploadPath, $fileName);
            $path = 'uploads/'.$fileName;
        }

        // Chủ đề
        $idChuDe = $request->id_chu_de;
        if ($request->filled('ten_chude_moi')) {
            $chuDe = ChuDe::create(['ten_chude' => $request->ten_chude_moi]);
            $idChuDe = $chuDe->id_chu_de;
        }

        // Tạo bài viết
        $bv = BaiViet::create([
            'nguoi_dung_id' => $userId,
            'noi_dung' => $request->noi_dung,
            'duong_dan_hinh_anh' => $path,
            'id_chu_de' => $idChuDe,
        ]);

        // Địa điểm
        if ($request->filled('ten_dia_diem') || $request->filled('dia_chi')) {
            DiaDiem::create([
                'ten_dia_diem' => $request->ten_dia_diem,
                'dia_chi' => $request->dia_chi,
                'bai_viet_id' => $bv->bai_viet_id,
            ]);
        }

        // Đánh giá
        if ($request->filled('danh_gia')) {
            DanhGia::create([
                'bai_viet_id' => $bv->bai_viet_id,
                'nguoi_dung_id' => $userId,
                'so_sao' => $request->danh_gia
            ]);
        }

        return redirect()->route('posts.index')->with('success', 'Đăng bài viết và đánh giá thành công!');
    }

    // FORM SỬA BÀI VIẾT (tên mới của bạn)
    public function edit($id)
    {
        $baiViet = BaiViet::with('diaDiem')->findOrFail($id);
        $chudes = ChuDe::all();

        // ---- VIEW MỚI ----
        return view('baiviet.sua-baiviet', compact('baiViet', 'chudes'));
    }

    // UPDATE BÀI VIẾT
    public function update(Request $request, $id)
    {
        $bv = BaiViet::findOrFail($id);

        $request->validate([
            'noi_dung' => 'required|string',
            'id_chu_de' => 'nullable|exists:chude,id_chu_de',
            'ten_chude_moi' => 'nullable|string|max:255',
            'duong_dan_hinh_anh' => 'nullable|file|mimes:jpg,jpeg,png,mp4|max:20480',
            'ten_dia_diem' => 'nullable|string|max:255',
            'dia_chi' => 'nullable|string|max:255',
        ]);

        // ảnh mới
        if ($request->hasFile('duong_dan_hinh_anh')) {
            $file = $request->file('duong_dan_hinh_anh');
            $fileName = time().'_'.preg_replace('/\s+/', '_', $file->getClientOriginalName());

            $uploadPath = public_path('uploads');
            if (!file_exists($uploadPath)) mkdir($uploadPath, 0755, true);

            // xóa ảnh cũ
            if ($bv->duong_dan_hinh_anh && file_exists(public_path($bv->duong_dan_hinh_anh))) {
                unlink(public_path($bv->duong_dan_hinh_anh));
            }

            $file->move($uploadPath, $fileName);
            $bv->duong_dan_hinh_anh = 'uploads/'.$fileName;
        }

        // chủ đề
        if ($request->filled('ten_chude_moi')) {
            $chuDe = ChuDe::create(['ten_chude' => $request->ten_chude_moi]);
            $bv->id_chu_de = $chuDe->id_chu_de;
        } elseif ($request->id_chu_de) {
            $bv->id_chu_de = $request->id_chu_de;
        }

        $bv->noi_dung = $request->noi_dung;
        $bv->save();

        // địa điểm
        if ($request->filled('ten_dia_diem') || $request->filled('dia_chi')) {
            if ($bv->diaDiem) {
                $bv->diaDiem->update([
                    'ten_dia_diem' => $request->ten_dia_diem,
                    'dia_chi' => $request->dia_chi,
                ]);
            } else {
                DiaDiem::create([
                    'ten_dia_diem' => $request->ten_dia_diem,
                    'dia_chi' => $request->dia_chi,
                    'bai_viet_id' => $bv->bai_viet_id,
                ]);
            }
        }

        return redirect()->route('posts.index')->with('success', 'Cập nhật bài viết thành công!');
    }

    // XÓA BÀI VIẾT
    public function destroy($id)
    {
        $bv = BaiViet::findOrFail($id);

        if ($bv->duong_dan_hinh_anh && file_exists(public_path($bv->duong_dan_hinh_anh))) {
            unlink(public_path($bv->duong_dan_hinh_anh));
        }

        $bv->delete();
        return response()->json(['success' => true, 'postId' => $id]);
    }

    // ĐÁNH GIÁ
    public function ratePost(Request $request, $postId)
    {
        $userId = session('nguoi_dung_id');
        $so_sao = $request->input('so_sao');

        $bv = BaiViet::findOrFail($postId);

        $bv->danhGias()->updateOrCreate(
            ['nguoi_dung_id' => $userId],
            ['so_sao' => $so_sao]
        );

        return response()->json([
            'diem_trung_binh' => round($bv->danhGias()->avg('so_sao'), 1),
            'luot_danh_gia' => $bv->danhGias()->count()
        ]);
    }

    // HIỂN THỊ BÀI VIẾT TỪ THÔNG BÁO
    public function show($id)
    {
        $currentUserId = session('nguoi_dung_id');

        $post = BaiViet::with(['nguoidung','chude','diaDiem','luotThich','binhLuan','danhGias'])
            ->findOrFail($id);

        

        $baiviets = collect([$post]);

        // ---- VIEW MỚI ----   
        return view('baiviet.link-thongbao', compact('baiviets', 'currentUserId'));
    }
    // Lấy các bình luận trên bài viết của bạn (khác người đăng bài)
public function commentsOnMyPosts()
{
    $currentUserId = session('nguoi_dung_id');

    // Lấy tất cả bài viết của người dùng hiện tại
    $myPosts = BaiViet::with(['binhLuan.nguoidung', 'binhLuan.replies'])
                ->where('nguoi_dung_id', $currentUserId)
                ->get();

    // Tạo collection comment từ các bài viết này, loại bỏ comment của chính bạn
    $comments = collect();

    foreach ($myPosts as $post) {
        foreach ($post->binhLuan as $cm) {
            if ($cm->nguoi_dung_id != $currentUserId) {
                $comments->push([
                    'post' => $post,
                    'comment' => $cm,
                    'replies' => $cm->replies // trả về cả reply
                ]);
            }
        }
    }

    // Sắp xếp theo thời gian mới nhất
    $comments = $comments->sortByDesc(function($item) {
        return $item['comment']->ngay_tao;
    });

    return view('baiviet.link-thongbao', compact('comments'));
}

}
