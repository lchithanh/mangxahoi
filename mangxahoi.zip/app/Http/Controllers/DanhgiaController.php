<?php

namespace App\Http\Controllers;

use App\Models\BaiViet;
use Illuminate\Http\Request;
use App\Models\DanhGia;
use App\Http\Controllers\Notification; // import Notification controller
use Illuminate\Support\Facades\Session;

class DanhGiaController extends Controller
{
    public function update(Request $request, $id)
    {
        // Validate số sao
        $request->validate(['so_sao' => 'required|numeric|min:0|max:5']);
        $userId = session('nguoi_dung_id'); // hoặc auth()->id() nếu dùng auth

        if (!$userId) {
            return response()->json(['error' => 'Chưa đăng nhập'], 401);
        }

        // Thêm hoặc cập nhật đánh giá của user
        $danhGia = DanhGia::updateOrCreate(
            ['bai_viet_id' => $id, 'nguoi_dung_id' => $userId],
            ['so_sao' => $request->so_sao]
        );

        // Lấy bài viết
        $post = BaiViet::find($id);

        // Nếu đánh giá bài của người khác, tạo thông báo
        if ($post && $post->nguoi_dung_id != $userId) {
            $user = $post->nguoi_dung_id; // người nhận
            $rater = \App\Models\NguoiDung::find($userId);
            $raterName = $rater ? $rater->ho_va_ten : 'Người dùng';

            Notification::createNotification(
                $post->nguoi_dung_id, // người nhận
                $userId,              // người thực hiện đánh giá
                'rating',             // loại thông báo
                "{$raterName} đã đánh giá bài viết của bạn.", // nội dung
                url('/posts/' . $post->bai_viet_id) // link bài viết
            );
        }

        // Tính điểm trung bình và số lượt đánh giá
        $diemTB = DanhGia::where('bai_viet_id', $id)->avg('so_sao');
        $luotDanhGia = DanhGia::where('bai_viet_id', $id)->count();

        // Trả về JSON
        return response()->json([
            'diem_trung_binh' => round($diemTB, 2),
            'luot_danh_gia' => $luotDanhGia
        ]);
    }

    public function getRaters($postId)
    {
        $post = BaiViet::with('danhGias.nguoiDung')->findOrFail($postId);

        $raters = $post->danhGias->map(function($dg){
            return [
                'name' => $dg->nguoiDung->ho_va_ten ?? 'Khách',
                'avatar' => $dg->nguoiDung->anh_dai_dien,
                'rating' => $dg->so_sao
            ];
        });

        return response()->json($raters);
    }
}
