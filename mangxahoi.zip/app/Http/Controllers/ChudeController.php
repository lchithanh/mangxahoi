<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChuDe;
use App\Models\BaiViet;
use App\Models\NguoiDung;

class ChuDeController extends Controller
{


public function show($id)
{
    $chude = ChuDe::findOrFail($id);

    $baiviets = BaiViet::with(['nguoidung','chude', 'luotThich', 'luuBaiViet', 'binhLuan', 'diaDiem'])
                ->where('id_chu_de', $id)
                ->orderByDesc('created_at')
                ->paginate(10);
    $currentUserId = session('nguoi_dung_id'); // ⚠️ THÊM DÒNG NÀY

    return view('chude.danhsach-chude', compact('chude', 'baiviets', 'currentUserId')); // ⚠️ THÊM VÀO
}



}
