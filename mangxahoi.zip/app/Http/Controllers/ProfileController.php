<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\NguoiDung;
use App\Models\BaiViet;

class ProfileController extends Controller
{
    // Lấy người dùng hiện tại từ session
    protected function getCurrentUser()
    {
        $id = session('nguoi_dung_id');
        if (!$id) return null;
        return NguoiDung::find($id);
    }

    // Hiển thị form setup profile
    public function setup()
    {
        $nguoiDung = $this->getCurrentUser();
        if (!$nguoiDung) return redirect()->route('login')->with('error', 'Vui lòng đăng nhập trước');

        return view('trangcanhan.setup-hoso', compact('nguoiDung'));
    }

    // Xử lý POST cập nhật profile
    public function updateProfile(Request $request)
    {
        $nguoiDung = $this->getCurrentUser();
        if (!$nguoiDung) return redirect()->route('login');

        $request->validate([
            'ho_va_ten' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'ngay_sinh' => 'nullable|date',
            'dia_chi' => 'nullable|string|max:255',
            'sdt' => 'nullable|string|max:20',
            'anh_dai_dien' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $nguoiDung->fill([
            'ho_va_ten' => $request->ho_va_ten,
            'email' => $request->email,
            'ngay_sinh' => $request->ngay_sinh,
            'dia_chi' => $request->dia_chi,
            'sdt' => $request->sdt,
        ]);

        if ($request->hasFile('anh_dai_dien')) {
            $file = $request->file('anh_dai_dien');
            $nguoiDung->anh_dai_dien = $file->store('avatars', 'public');
        }

        $nguoiDung->save();

        return redirect()->route('profile.index')->with('success', 'Cập nhật hồ sơ thành công');
    }

    // Trang cá nhân của chính mình với bài viết
    public function index()
    {
        $nguoiDung = $this->getCurrentUser();
        if (!$nguoiDung) return redirect()->route('login')->with('error', 'Vui lòng đăng nhập trước');

        $isOwner = true;

        // Lấy tất cả bài viết của chính mình, sắp xếp mới nhất
        $baiviets = BaiViet::where('nguoi_dung_id', $nguoiDung->nguoi_dung_id)
            ->with(['nguoiDung', 'luotThich', 'binhLuan', 'diaDiem', 'chuDe'])
            ->latest()
            ->get();

        return view('trangcanhan.hoso', compact('nguoiDung', 'isOwner', 'baiviets'));
    }

    // Xem profile người khác
    public function show($id)
    {
        $nguoiDung = NguoiDung::findOrFail($id);
        $idDangNhap = session('nguoi_dung_id');
        $isOwner = ($idDangNhap == $nguoiDung->nguoi_dung_id);

        // Lấy bài viết của người này
        $baiviets = BaiViet::where('nguoi_dung_id', $nguoiDung->nguoi_dung_id)
            ->with(['nguoiDung', 'luotThich', 'binhLuan', 'diaDiem', 'chuDe'])
            ->latest()
            ->get();

        return view('trangcanhan.hoso', compact('nguoiDung', 'isOwner', 'baiviets'));
    }
}
