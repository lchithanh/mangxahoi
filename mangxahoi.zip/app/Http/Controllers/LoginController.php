<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\NguoiDung;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    // Hiển thị form đăng nhập
    public function showLoginForm()
    {
        return view('login');
    }

    // Xử lý đăng nhập
    public function login(Request $request)
    {
        $request->validate([
            'ten_dang_nhap' => 'required', // vẫn giữ tên input cũ
            'mat_khau' => 'required',
        ]);

        // ✅ Cho phép người dùng nhập tên đăng nhập hoặc email
        $loginInput = $request->ten_dang_nhap;
        $nguoiDung = NguoiDung::where('ten_dang_nhap', $loginInput)
                        ->orWhere('email', $loginInput)
                        ->first();

        // ✅ Kiểm tra mật khẩu
        if ($nguoiDung && Hash::check($request->mat_khau, $nguoiDung->mat_khau_ma_hoa)) {
            session(['nguoi_dung_id' => $nguoiDung->nguoi_dung_id]);

            if (method_exists($nguoiDung, 'daHoanThienHoSo') && $nguoiDung->daHoanThienHoSo()) {
                return redirect()->route('profile.index');
            } else {
                return redirect()->route('profile.setup');
            }
        }

        return back()->withErrors(['ten_dang_nhap' => 'Tên đăng nhập / email hoặc mật khẩu không đúng']);
    }

    // Đăng xuất
    public function logout(Request $request)
    {
        // Xóa session
        $request->session()->forget('nguoi_dung_id');

        // Chuyển về trang đăng nhập
        return redirect()->route('login')->with('success', 'Đăng xuất thành công');
    }
}
