<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #4a90e2, #50e3c2);
        }

        .login-wrapper {
            display: flex;
            width: 800px;      /* Khung cố định */
            height: 500px;     /* Khung cố định */
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            background: #ffffff30;
            backdrop-filter: blur(10px);
        }


        /* Cột logo */
        .login-left {
            flex: 2.5;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(74,144,226,0.9), rgba(80,227,194,0.9));
        }

        .login-left img {
            max-width: 200px;
            width: 70%;
            height: auto;
            object-fit: contain;
            border-radius: 12px;
            transition: transform 0.3s ease;
        }

        .login-left img:hover {
            transform: scale(1.05);
        }

        /* Cột form */
        .login-right {
            flex: 1.5;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            padding: 40px 30px;
        }

        .login-container {
            width: 100%;
            max-width: 300px;
        }

        .login-container h2 {
            margin-bottom: 25px;
            font-weight: 700;
            color: #333;
            text-align: center;
        }

        .login-container .form-control {
            border-radius: 8px;
            transition: box-shadow 0.3s ease, border-color 0.3s ease;
        }

        .login-container .form-control:focus {
            border-color: #4a90e2;
            box-shadow: 0 0 8px rgba(74,144,226,0.3);
        }

        .btn-primary {
            width: 100%;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background: #357ab8;
        }

        .login-container a {
            text-decoration: none;
            color: #4a90e2;
            transition: color 0.3s ease;
        }

        .login-container a:hover {
            color: #357ab8;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .login-wrapper {
                flex-direction: column;
                height: auto;
            }
            .login-left, .login-right {
                flex: unset;
                width: 100%;
                padding: 30px 20px;
            }
            .login-left img {
                max-width: 150px;
            }
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <!-- Cột logo -->
    <div class="login-left">
        <img src="{{ asset('images/logo.jpg') }}" alt="Logo">
    </div>

    <!-- Cột form đăng nhập -->
    <div class="login-right">
        <div class="login-container">
            <h2>Đăng nhập</h2>

            @if($errors->any())
                <div class="alert alert-danger">
                    {{ $errors->first() }}
                </div>
            @endif

            <form action="{{ route('login.submit') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="ten_dang_nhap" class="form-label">Tên đăng nhập</label>
                    <input type="text" class="form-control" id="ten_dang_nhap" name="ten_dang_nhap" value="{{ old('ten_dang_nhap') }}" required>
                </div>
                <div class="mb-3">
                    <label for="mat_khau" class="form-label">Mật khẩu</label>
                    <input type="password" class="form-control" id="mat_khau" name="mat_khau" required>
                </div>
                <button type="submit" class="btn btn-primary">Đăng nhập</button>
            </form>

            <div class="text-center mt-3">
                <small>Chưa có tài khoản? <a href="{{ route('register') }}">Đăng ký</a></small>
            </div>
        </div>
    </div>
</div>

</body>
</html>
