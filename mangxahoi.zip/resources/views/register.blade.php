<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #4a90e2, #50e3c2);
        }

        .register-wrapper {
            display: flex;
            width: 900px;       /* Tăng rộng hơn để không bị cắt input */
            height:700px;      /* Form nhiều hơn nên tăng chiều cao */
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            background: #ffffff30;
            backdrop-filter: blur(10px);
        }

        /* Cột logo */
        .register-left {
            flex: 2.5;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(74,144,226,0.9), rgba(80,227,194,0.9));
        }

        .register-left img {
            max-width: 220px;
            width: 70%;
            height: auto;
            object-fit: contain;
            border-radius: 12px;
            transition: transform 0.3s ease;
        }

        .register-left img:hover {
            transform: scale(1.05);
        }

        /* Cột form */
        .register-right {
            flex: 1.5;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            padding: 40px 30px;
            overflow-y: auto;
        }

        .register-container {
            width: 100%;
            max-width: 320px;
        }

        .register-container h2 {
            margin-bottom: 25px;
            font-weight: 700;
            color: #333;
            text-align: center;
        }

        .register-container .form-control {
            border-radius: 8px;
            height: 43px;
            transition: box-shadow 0.3s ease, border-color 0.3s ease;
        }

        .register-container .form-control:focus {
            border-color: #4a90e2;
            box-shadow: 0 0 8px rgba(74,144,226,0.3);
        }

        .btn-primary {
            width: 100%;
            border-radius: 8px;
            transition: background 0.3s ease;
            height: 45px;
        }

        .btn-primary:hover {
            background: #357ab8;
        }

        @media (max-width: 768px) {
            .register-wrapper {
                flex-direction: column;
                height: auto;
            }

            .register-left, .register-right {
                flex: unset;
                width: 100%;
                padding: 30px 20px;
            }

            .register-left img {
                max-width: 150px;
            }
        }
    </style>
</head>
<body>

<div class="register-wrapper">
    <!-- Cột logo -->
    <div class="register-left">
        <img src="{{ asset('images/logo.jpg') }}" alt="Logo">
    </div>

    <!-- Cột form đăng ký -->
    <div class="register-right">
        <div class="register-container">
            <h2>Đăng ký</h2>

            @if($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('register.submit') }}" method="POST">
                @csrf

                <div class="mb-3">
                    <label class="form-label">Tên đăng nhập</label>
                    <input type="text" class="form-control" name="ten_dang_nhap" value="{{ old('ten_dang_nhap') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="{{ old('email') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Mật khẩu</label>
                    <input type="password" class="form-control" name="mat_khau" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Họ và tên</label>
                    <input type="text" class="form-control" name="ho_va_ten" value="{{ old('ho_va_ten') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ngày sinh</label>
                    <input type="date" class="form-control" name="ngay_sinh" value="{{ old('ngay_sinh') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Địa chỉ</label>
                    <input type="text" class="form-control" name="dia_chi" value="{{ old('dia_chi') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" class="form-control" name="sdt" value="{{ old('sdt') }}">
                </div>

                <button type="submit" class="btn btn-primary">Đăng ký</button>

                <div class="text-center mt-3">
                    <small>Đã có tài khoản? <a href="{{ route('login') }}">Đăng nhập</a></small>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
