<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Mạng Xã Hội')</title>

    <!-- CSS chung -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    
    <!-- CSS -->
<link rel="stylesheet" href="{{ asset('css/layout.css') }}">
</head>
<body>
<?php if (session('error')): ?>
<script>
    alert("<?= session('error') ?>");
</script>
<?php endif; ?>
<!-- HEADER -->

@include('layout.header')

<!-- MAIN 3 CỘT -->
<div class="container-fluid mt-4 fb-container">
    <div class="row justify-content-center">

        <!-- CỘT TRÁI -->
        <aside class="col-3 d-none d-md-block fb-left">
            <div class="fb-left-menu">
                <a href="/" class="left-item"><i class="fa-solid fa-house"></i> Trang chủ</a>

                <!-- Dropdown Chủ đề -->
                <div class="mb-2">
                    <div class="left-item left-item-dropdown" id="btnChude">
                        <i class="fa-solid fa-tags"></i> Chủ đề <i class="fa-solid fa-caret-down float-end"></i>
                    </div>
                    <ul class="dropdown-chude shadow-sm bg-white border rounded mt-1" id="dropdownChude">
                        @isset($chudes)
                            @forelse($chudes as $cd)
                                <li><a href="{{ route('chude.show', $cd->id_chu_de) }}">{{ $cd->ten_chude }}</a></li>
                            @empty
                                <li class="text-muted">Chưa có chủ đề</li>
                            @endforelse
                        @else
                            <li class="text-muted">Chưa có chủ đề</li>
                        @endisset
                    </ul>
                </div>

                <a href="{{ route('thongbao.list') }}" class="left-item"><i class="fa-solid fa-bell"></i> Thông báo</a>
                <a href="{{ route('save.index') }}" class="left-item"><i class="fa-solid fa-bookmark"></i> Lưu trữ</a>
                <a href="{{ route('posts.create') }}" class="left-item"><i class="fa-solid fa-plus"></i> Thêm bài viết</a>
                <a href="{{ route('profile.index') }}" class="left-item"><i class="fa-solid fa-user"></i> Hồ sơ</a>
                <a href="/caidat" class="left-item"><i class="fa-solid fa-gear"></i> Cài đặt</a>

                @if(session()->has('nguoi_dung_id'))
                    <form action="{{ route('logout') }}" method="POST" class="mt-3">
                        @csrf
                        <button class="btn btn-danger w-100">Đăng xuất</button>
                    </form>
                @endif
            </div>
        </aside>

        <!-- CỘT GIỮA -->
        <main class="col-12 col-md-6 fb-center">
            @yield('content')
        </main>

        <!-- CỘT PHẢI -->
        <aside class="col-3 d-none d-md-block fb-right">
            @php $currentUser = session()->has('nguoi_dung_id') ? \App\Models\NguoiDung::find(session('nguoi_dung_id')) : null; @endphp
            <div class="fb-right-box shadow-sm">
                @if(!$currentUser)
                    <a href="{{ route('register') }}" class="btn btn-primary w-100 mb-2">Đăng ký</a>
                    <a href="{{ route('login') }}" class="btn btn-outline-primary w-100">Đăng nhập</a>
                @else
                    <div class="text-center mb-3">
                        <a href="{{ route('profile.index') }}">
                            <img src="{{ $currentUser->anh_dai_dien ? asset('storage/' . $currentUser->anh_dai_dien) : 'https://via.placeholder.com/80' }}" class="fb-right-avatar">
                        </a>
                        <p class="fw-bold mt-2">{{ $currentUser->ho_va_ten ?? $currentUser->ten_dang_nhap }}</p>
                        <small class="text-muted">Chúc bạn một ngày tốt lành!</small>
                    </div>
                    <a href="/messages" class="btn btn-success w-100 mb-2">Tin nhắn</a>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="btn btn-outline-danger w-100">Đăng xuất</button>
                    </form>
                @endif
            </div>
        </aside>

    </div>
</div>

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<!-- JS -->
<!-- JS cuối body -->
<script src="{{ asset('js/layout.js') }}"></script>
</body>
</html>
