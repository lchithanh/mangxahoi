<nav class="fb-header shadow-sm">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <!-- Logo + Search -->
        <div class="d-flex align-items-center gap-3">
            <a href="/" class="fb-logo">
                <img src="{{ asset('images/logo.jpg') }}" alt="Logo" class="fb-logo-img">
            </a>
            <div class="fb-search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" placeholder="Tìm kiếm trên mạng xã hội...">
            </div>
        </div>


    <!-- Menu giữa -->
    <div class="fb-middle-menu d-none d-md-flex">
        <a href="/" class="fb-middle-item {{ Request::is('/') ? 'active' : '' }}">
            <i class="fa-solid fa-house"></i>
        </a>
        <a href="/chude" class="fb-middle-item {{ Request::is('chude') ? 'active' : '' }}">
            <i class="fa-solid fa-layer-group"></i>
        </a>

        {{-- Thông báo --}}
        @php
            $userId = session('nguoi_dung_id') ?? 0;
            if($userId) {
                $thongbaos = \App\Models\ThongBao::where('nguoi_dung_id', $userId)
                                ->orderBy('thoi_gian','desc')
                                ->take(5)
                                ->get();
                $chuaXem = \App\Models\ThongBao::where('nguoi_dung_id', $userId)
                                ->where('da_xem', 0)
                                ->count();
            } else {
                $thongbaos = collect();
                $chuaXem = 0;
            }
        @endphp

        <div class="fb-middle-item position-relative dropdown">
            <a href="#" class="text-dark" id="thongbaoDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-bell"></i>
                @if($chuaXem > 0)
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $chuaXem }}
                    </span>
                @endif
            </a>

            <ul class="dropdown-menu dropdown-menu-end p-2" style="min-width:300px;" aria-labelledby="thongbaoDropdown">
                @forelse($thongbaos as $tb)
                    <li class="dropdown-item {{ $tb->da_xem ? '' : 'fw-bold' }}">
                        <a href="{{ $tb->link ?? '#' }}" class="text-decoration-none text-dark d-flex justify-content-between">
                            <span>{{ $tb->noi_dung }}</span>
                            
                            <small class="text-muted">
                                {{ $tb->thoi_gian ? $tb->thoi_gian->diffForHumans() : '' }}
                            </small>
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                @empty
                    <li class="dropdown-item text-center text-muted">Không có thông báo</li>
                @endforelse
                <li class="text-center"><a href="#">Xem tất cả</a></li>
            </ul>
        </div>
    </div>

    <!-- Avatar + nút tạo bài viết -->
    <div class="d-flex align-items-center gap-3">
        <a href="{{ route('posts.create') }}" class="circle-btn"><i class="fa-solid fa-square-plus"></i></a>
        <a href="{{ route('profile.index') }}" class="fb-avatar">
            @php
                $nguoiDung = session()->has('nguoi_dung_id') ? \App\Models\NguoiDung::find(session('nguoi_dung_id')) : null;
            @endphp
            <img src="{{ $nguoiDung && $nguoiDung->anh_dai_dien
                ? asset('storage/' . $nguoiDung->anh_dai_dien)
                : 'https://via.placeholder.com/40' }}">
        </a>
    </div>
</div>
</nav>
