<!-- resources/views/partials/raters-modal.blade.php -->
<div class="modal fade" id="ratersModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Danh sách người đánh giá</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Đóng"></button>
      </div>
      <div class="modal-body">
        <ul id="ratersList" class="list-group">
          <!-- Danh sách người đánh giá sẽ được render bằng JS -->
        </ul>
      </div>
    </div>
  </div>
</div>
