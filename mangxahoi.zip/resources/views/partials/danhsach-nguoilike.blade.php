<div class="modal fade" id="likersModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Danh sách người thích bài viết</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Đóng"></button>
      </div>
      <div class="modal-body">
        <ul id="likersList" class="list-group">
          <!-- Danh sách người thích sẽ được render ở đây -->
        </ul>
      </div>
    </div>
  </div>
</div>
