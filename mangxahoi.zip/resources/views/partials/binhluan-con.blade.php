<div id="comment-{{ $cm->binh_luan_id }}" class="comment p-2 rounded-3 mb-2 ms-{{ $level*4 }}" style="background:#f8f9fa;">
    <strong>{{ $cm->nguoidung->ho_va_ten ?? 'Khách' }}</strong>: 
    <span class="comment-content">{{ $cm->noi_dung }}</span><br>
    <small class="text-muted">{{ $cm->ngay_tao->format('Y-m-d H:i') }}</small>

    <button class="btn btn-sm btn-link p-0 mt-1" onclick="toggleReply({{ $cm->binh_luan_id }})">↩️ Trả lời</button>

    @if($cm->nguoi_dung_id == $currentUserId)
        <button class="btn btn-sm btn-link p-0 mt-1" onclick="toggleEdit({{ $cm->binh_luan_id }})">✏️ Sửa</button>
        <button class="btn btn-sm btn-link p-0 mt-1 text-danger" onclick="deleteComment({{ $cm->binh_luan_id }})">🗑️ Xóa</button>

        <div id="edit-{{ $cm->binh_luan_id }}" style="display:none; margin-top:5px;">
            <form class="edit-form" data-id="{{ $cm->binh_luan_id }}" action="{{ route('comments.update', $cm->binh_luan_id) }}">
                @csrf
                <input type="text" name="noi_dung" class="form-control mb-1" value="{{ $cm->noi_dung }}">
                <button class="btn btn-sm btn-primary">Lưu</button>
            </form>
        </div>
    @endif

    <div id="reply-{{ $cm->binh_luan_id }}" style="display:none; margin-left: 15px;">
        <form class="reply-form" data-post-id="{{ $postId }}">
            @csrf
            <input type="hidden" name="binh_luan_cha_id" value="{{ $cm->binh_luan_id }}">
            <div class="input-group mb-2">
                <input type="text" name="noi_dung" class="form-control" required placeholder="Viết trả lời...">
                <button class="btn btn-secondary">Gửi</button>
            </div>
        </form>

        @foreach($cm->replies as $reply)
            @include('partials.binhluan-con', [
                'cm' => $reply,
                'postId' => $postId,
                'level' => $level + 1
            ])
        @endforeach
    </div>
</div>
