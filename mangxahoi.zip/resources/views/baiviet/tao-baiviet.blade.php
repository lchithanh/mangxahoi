@extends('layout.master')
@section('title', 'Tạo bài viết')

@section('content')

<link rel="stylesheet" href="{{ asset('css/post-create.css') }}">

<div class="container py-5">
    <div class="post-card shadow">
        <div class="post-header">
            <h4 class="mb-0">📝 Tạo bài viết</h4>
        </div>

        <div class="post-body">

            <form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                {{-- Nội dung --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">📝 Nội dung</label>
                    <textarea name="noi_dung" rows="4" class="form-control"
                              placeholder="Bạn đang nghĩ gì?"
                              required>{{ old('noi_dung') }}</textarea>
                </div>

                {{-- Chủ đề --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">🏷️ Chủ đề</label>
                    <select name="id_chu_de" class="form-control">
                        <option value="">-- Chọn chủ đề --</option>
                        @foreach($chudes as $cd)
                            <option value="{{ $cd->id_chu_de }}">{{ $cd->ten_chude }}</option>
                        @endforeach
                    </select>
                    <input type="text" name="ten_chude_moi" placeholder="Nhập chủ đề mới (nếu có)" class="form-control">
                    <small class="text-muted">Nếu nhập tên chủ đề mới, hệ thống sẽ tạo chủ đề này cho bài viết.</small>
                </div>

                {{-- Hình ảnh / Video --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">🖼️ Hình ảnh / Video</label>
                    <input type="file" name="duong_dan_hinh_anh" class="form-control" accept="image/*,video/*">
                </div>

                {{-- Địa điểm --}}
<div class="row g-3 mb-4">
    <div class="col-md-8">
        <label class="form-label fw-bold">📍 Gắn thẻ địa điểm</label>
        <input type="text" name="ten_dia_diem" id="ten_dia_diem" class="form-control"
               placeholder="VD: Highlands Coffee Nguyễn Huệ"
               value="{{ old('ten_dia_diem', $baiViet->diaDiem->ten_dia_diem ?? '') }}">
    </div>
    <div class="col-md-4 d-flex align-items-end">
        <button type="button" id="btnGetAddress" class="btn btn-outline-primary w-100">
            📍 Lấy vị trí hiện tại
        </button>
    </div>
</div>

{{-- Địa chỉ cụ thể --}}
<div class="mb-4">
    <label class="form-label fw-bold">🏠 Địa chỉ cụ thể</label>
    <input type="text" name="dia_chi" id="dia_chi" class="form-control"
           placeholder="VD: 151 Nguyễn Huệ, Q.1, TP.HCM"
           value="{{ old('dia_chi', $baiViet->diaDiem->dia_chi ?? '') }}">
</div>


                {{-- Rating --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">⭐ Đánh giá</label>
                    <div class="rating-container">
                        @php
                            $soSao = old('danh_gia', 0);
                        @endphp
                        @for($i = 1; $i <= 5; $i++)
                            <i class="bi {{ $i <= $soSao ? 'bi-star-fill text-warning' : 'bi-star text-secondary' }} rating-star fs-4" 
                            data-value="{{ $i }}" style="cursor:pointer;"></i>
                        @endfor
                    </div>
                    <input type="hidden" name="danh_gia" id="danh_gia" value="{{ $soSao }}">
                    <small class="text-muted">Nhấn vào sao để chọn mức độ hài lòng (0–5).</small>
                </div>


                {{-- Submit --}}
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <button type="submit" class="btn btn-success px-4">🚀 Đăng bài</button>
                    <a href="{{ route('home') }}" class="btn btn-secondary px-4">Hủy</a>
                </div>

            </form>

        </div>
    </div>
</div>


<script src="{{ asset('js/tao.js') }}"></script>
@endsection
