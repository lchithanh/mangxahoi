@extends('layout.master')

@section('title', 'Thông báo')

@section('content')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Thông báo người dùng -->
@if(isset($thongbaos) && $thongbaos->count())
<div class="container my-3">
    <div class="list-group">
        @foreach($thongbaos as $tb)
        <div class="list-group-item d-flex justify-content-between align-items-center">
            <span>{{ $tb->noi_dung }}</span>
            <small class="text-muted">{{ $tb->created_at->diffForHumans() }}</small>
        </div>
        @endforeach
    </div>
</div>
@endif

@include('baiviet.danhsach-baiviet', [
    'baiviets' => $baiviets,
    'currentUserId' => session('nguoi_dung_id')
])
@endsection
