@extends('layout.master')
@section('title', 'Chỉnh sửa bài viết')

@section('content')

<link rel="stylesheet" href="{{ asset('css/post-create.css') }}">

<div class="container py-5">
    <div class="post-card shadow">
        <div class="post-header">
            <h4 class="mb-0">✏️ Chỉnh sửa bài viết</h4>
        </div>

        <div class="post-body">

            <form action="{{ route('posts.update', $baiViet->bai_viet_id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                {{-- Nội dung --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">📝 Nội dung</label>
                    <textarea name="noi_dung" rows="4" class="form-control" required>{{ old('noi_dung', $baiViet->noi_dung) }}</textarea>
                </div>

                {{-- Chủ đề --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">🏷️ Chủ đề</label>

                    {{-- Dropdown chủ đề --}}
                    <select name="id_chu_de" class="form-select mb-2">
                        <option value="">-- Chọn chủ đề có sẵn --</option>
                        @foreach($chudes as $cd)
                            <option value="{{ $cd->id_chu_de }}"
                                {{ (old('id_chu_de', $baiViet->chude->id_chu_de ?? '') == $cd->id_chu_de) ? 'selected' : '' }}>
                                {{ $cd->ten_chude }}
                            </option>
                        @endforeach
                    </select>

                    {{-- Nhập chủ đề mới --}}
                    <input type="text" name="ten_chude_moi" class="form-control"
                           placeholder="Hoặc nhập tên chủ đề mới"
                           value="{{ old('ten_chude_moi') }}">

                    <small class="text-muted">Nhập tên chủ đề mới nếu muốn thay đổi chủ đề bài viết.</small>
                </div>

                {{-- Hình ảnh / Video --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">🖼️ Hình ảnh / Video</label>
                    <input type="file" name="duong_dan_hinh_anh" class="form-control" accept="image/*,video/*">
                    @if($baiViet->duong_dan_hinh_anh)
                        <small class="text-muted">Hình hiện tại: {{ $baiViet->duong_dan_hinh_anh }}</small>
                    @endif
                </div>

                {{-- Địa điểm --}}
                <div class="row g-3 mb-4">
                    <div class="col-md-8">
                        <label class="form-label fw-bold">📍 Gắn thẻ địa điểm</label>
                        <input type="text" name="ten_dia_diem" id="ten_dia_diem" class="form-control"
                            placeholder="VD: Highlands Coffee Nguyễn Huệ"
                            value="{{ old('ten_dia_diem', $baiViet->diaDiem->ten_dia_diem ?? '') }}">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="button" id="btnGetAddress" class="btn btn-outline-primary w-100">
                            📍 Lấy vị trí hiện tại
                        </button>
                    </div>
                </div>

                {{-- Địa chỉ cụ thể --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">🏠 Địa chỉ cụ thể</label>
                    <input type="text" name="dia_chi" id="dia_chi" class="form-control"
                        placeholder="VD: 151 Nguyễn Huệ, Q.1, TP.HCM"
                        value="{{ old('dia_chi', $baiViet->diaDiem->dia_chi ?? '') }}">
                </div>


                {{-- Rating --}}
                <div class="mb-4">
                    <label class="form-label fw-bold">⭐ Đánh giá</label>
                    <div class="rating-container">
                        @for($i = 1; $i <= 5; $i++)
                            <span class="rating-star" data-value="{{ $i }}"
                                  @if(old('danh_gia', $baiViet->danh_gia) >= $i) class="selected" @endif>★</span>
                        @endfor
                    </div>
                    <input type="hidden" name="danh_gia" id="danh_gia"
                           value="{{ old('danh_gia', $baiViet->danh_gia) }}">
                    <small class="text-muted">Nhấn vào sao để chọn mức độ hài lòng (0–5).</small>
                </div>

                {{-- Submit --}}
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <button type="submit" class="btn btn-success px-4">💾 Cập nhật</button>
                    <a href="{{ route('home') }}" class="btn btn-secondary px-4">Hủy</a>
                </div>

            </form>

        </div>
    </div>
</div>

<script>
    const stars = document.querySelectorAll('.rating-star');
    const ratingInput = document.getElementById('danh_gia');

    stars.forEach(star => {
        star.addEventListener('click', () => {
            const value = star.getAttribute('data-value');
            ratingInput.value = value;
            stars.forEach(s => s.classList.remove('selected'));
            for (let i = 0; i < value; i++) {
                stars[i].classList.add('selected');
            }
        });
    });
</script>
{{-- JS xử lý lấy vị trí hiện tại --}}
<script>
    document.getElementById('btnGetAddress').addEventListener('click', () => {
        const addressInput = document.getElementById('dia_chi');
        const nameInput = document.getElementById('ten_dia_diem');

        if (!navigator.geolocation) {
            alert('Trình duyệt của bạn không hỗ trợ định vị.');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;

                try {
                    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
                    const data = await res.json();

                    if (data && data.display_name) {
                        addressInput.value = data.display_name;

                        // Tự điền tên địa điểm nếu có
                        if (data.name) {
                            nameInput.value = data.name;
                        }
                    } else {
                        alert('Không lấy được địa chỉ từ vị trí hiện tại.');
                    }
                } catch (err) {
                    console.error(err);
                    alert('Lỗi khi lấy địa chỉ từ vị trí.');
                }
            },
            (error) => {
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        alert('Bạn đã từ chối truy cập vị trí.');
                        break;
                    case error.POSITION_UNAVAILABLE:
                        alert('Không xác định được vị trí.');
                        break;
                    case error.TIMEOUT:
                        alert('Lấy vị trí quá thời gian cho phép.');
                        break;
                    default:
                        alert('Đã xảy ra lỗi khi lấy vị trí.');
                }
            }
        );
    });
</script>
@endsection
