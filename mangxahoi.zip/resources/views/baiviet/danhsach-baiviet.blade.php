<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách bài viết</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background-color:#f5f6fa; }
        .avatar-hover:hover { transform:scale(1.05); transition:0.2s; }
        .name-hover:hover { text-decoration:underline; }
        .liked { color:red; }
        .comment, .replies div { word-break:break-word; }
    </style>

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <script>
        window.csrf = document.querySelector('meta[name="csrf-token"]').content;
    </script>
    
</head>
<body>

<div class="container my-4">

@foreach($baiviets as $bv)

@php
    $user = $bv->nguoidung;
    $isOwner = ($user && $user->nguoi_dung_id == $currentUserId);
    $liked = $bv->luotThich->contains('nguoi_dung_id', $currentUserId);
    $saved = $bv->luuBaiViet->contains('nguoi_dung_id', $currentUserId);
    $avgRating = round($bv->danhGias->avg('so_sao') ?? 0);
$userRating = $bv->danhGias->where('nguoi_dung_id', $currentUserId)->first()->so_sao ?? 0;
 $fullStars = floor($avgRating); // số sao đầy đủ
    $halfStar = ($avgRating - $fullStars) >= 0.5 ? 1 : 0; // có sao nửa không
    $emptyStars = 5 - $fullStars - $halfStar; // số sao trống
@endphp

<div class="card mb-4 shadow-sm rounded-3 position-relative" id="post-{{ $bv->bai_viet_id }}">
    <div class="card-body">

        <!-- Menu -->
        <div class="position-absolute top-0 end-0 p-2">
            <div class="dropdown">
                <button class="btn btn-sm btn-light" data-bs-toggle="dropdown">⋮</button>
                <ul class="dropdown-menu dropdown-menu-end">
                    @if($isOwner)
                        <li>
                        <!-- Nút Sửa -->
                            <a href="{{ route('posts.edit', $bv->bai_viet_id) }}" 
                            class="btn btn-sm btn-primary">
                                <i class="bi bi-pencil"></i> Sửa
                            </a>                        
                        </li>
                        <li>
                    <!-- Nút Xóa -->
                        <button class="btn btn-sm btn-danger delete-btn" 
                                data-post-id="{{ $bv->bai_viet_id }}">
                            <i class="bi bi-trash"></i> Xóa
                        </button>
                     
                         </li>
                    @endif
                    <li>
                        @php
                            $isSavedPage = $isSavedPage ?? false; // nhận biến từ view
                        @endphp

                        <button class="btn btn-sm save-toggle-btn {{ $saved ? 'btn-success' : 'btn-outline-secondary' }}"
                                data-post-id="{{ $bv->bai_viet_id }}"
                                data-saved="{{ $saved ? 1 : 0 }}"
                                data-saved-page="{{ $isSavedPage ? 1 : 0 }}">
                                <!-- data-saved-page = 1 nếu đang ở trang Saved.
                                data-saved = 1 nếu bài viết đã lưu.
                                Nút dùng chung cả 2 trang, trạng thái cập nhật ngay khi click.-->
                            @if($isSavedPage || $saved)
                                Hủy lưu
                            @else
                                Lưu bài viết
                            @endif
                        </button>
                    </li>

                </ul>
            </div>
        </div>

        <!-- Người đăng -->
        <div class="d-flex align-items-center mb-3">
            <a href="{{ $isOwner ? route('profile.index') : route('profile.view', $user->nguoi_dung_id ?? 0) }}">
                <img src="{{ $user->anh_dai_dien ? asset('storage/'.$user->anh_dai_dien) : 'https://via.placeholder.com/50' }}"
                     class="rounded-circle me-3 avatar-hover" width="50" height="50">
            </a>

            <div>
                <a href="{{ $isOwner ? route('profile.index') : route('profile.view', $user->nguoi_dung_id ?? 0) }}"
                   class="fw-bold text-dark text-decoration-none name-hover">
                    {{ $user->ho_va_ten ?? 'Khách' }}
                </a><br>
                <small class="text-muted">
                    {{ $bv->created_at->diffForHumans() }}
                    @if($bv->chude)
                        <span class="badge bg-info">{{ $bv->chude->ten_chude }}</span>
                    @endif
                </small>
            </div>
        </div>

        <!-- Nội dung -->
        <p>{{ $bv->noi_dung }}</p>

        <!-- Hình ảnh -->
        @if($bv->duong_dan_hinh_anh)
        <div class="text-center mb-3">
            <img src="{{ asset($bv->duong_dan_hinh_anh) }}" alt="Image"
                 class="img-fluid rounded-3"
                 style="max-height:400px; object-fit:cover;">
        </div>
        @endif

        <!-- Địa điểm -->
        @if($bv->diaDiem)
        <p class="text-muted">
            📍 <strong>{{ $bv->diaDiem->ten_dia_diem }}</strong>
            @if($bv->diaDiem->dia_chi) - {{ $bv->diaDiem->dia_chi }} @endif
        </p>
        @endif

<!-- Trung bình -->
<div class="mb-2 avg-rating" data-post-id="{{ $bv->bai_viet_id }}">
    <span class="fw-bold">⭐ Trung bình:</span>

    {{-- full stars --}}
    @for($i = 0; $i < $fullStars; $i++)
        <i class="bi bi-star-fill text-warning fs-5"></i>
    @endfor

    {{-- half star --}}
    @if($halfStar)
        <i class="bi bi-star-half text-warning fs-5"></i>
    @endif

    {{-- empty stars --}}
    @for($i = 0; $i < $emptyStars; $i++)
        <i class="bi bi-star text-secondary fs-5"></i>
    @endfor

    <small style="cursor:pointer; text-decoration:underline;" 
           onclick="showRaters({{ $bv->bai_viet_id }})">
         ({{ number_format($avgRating, 1) }} / 5 từ {{ $bv->danhGias->count() }} đánh giá)
    </small>
</div>

<!-- Đánh giá của người dùng -->
<div class="mb-3 user-rating" data-post-id="{{ $bv->bai_viet_id }}">
    <span class="fw-bold">Đánh giá của bạn:</span>
    @for($i=1;$i<=5;$i++)
        <i class="bi rating-star {{ $i <= $userRating ? 'bi-star-fill text-warning' : 'bi-star text-secondary' }}" data-value="{{ $i }}" style="cursor:pointer;"></i>
    @endfor
</div>


        <!-- Like + Comment -->
        <div class="d-flex align-items-center gap-3 mb-3">
            <button class="btn btn-outline-danger btn-like" data-id="{{ $bv->bai_viet_id }}">
                <i class="bi bi-heart"></i> 
                <span class="like-count">{{ $bv->luotThich->count() }}</span>
            </button>


            <small style="cursor:pointer; text-decoration:underline; margin-left:5px;" 
                onclick="showLikers({{ $bv->bai_viet_id }})">
                xem lượt thích
            </small>



            <button class="btn btn-sm btn-outline-primary"
                    onclick="toggleComment({{ $bv->bai_viet_id }})">
                💬 Bình luận ({{ $bv->binhLuan->count() }})
            </button>
        </div>

      <!-- Form bình luận -->
        <div id="comment-box-{{ $bv->bai_viet_id }}" style="display: none;">
             <div id="comment-{{ $bv->bai_viet_id }}">
        
                <!-- Form comment cha -->
                <form class="comment-form mb-3" data-post-id="{{ $bv->bai_viet_id }}">
                    @csrf
                    <div class="input-group">
                        <input type="text" name="noi_dung" class="form-control" placeholder="Viết bình luận..." required>
                        <button class="btn btn-primary">Gửi</button>
                    </div>
                </form>

                <!-- Danh sách comment -->
                <div class="comment-list">
                    @foreach($bv->binhLuan->where('binh_luan_cha_id', null) as $cm)
                        @include('partials.binhluan-con', [
                            'cm' => $cm,
                            'postId' => $bv->bai_viet_id,
                            'level' => 0
                        ])
                    @endforeach
                </div>
            </div>
        </div>

    </div>
</div>

@endforeach

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('js/binhluan.js') }}"></script>
<script src="{{ asset('js/thich.js') }}"></script>
<script src="{{ asset('js/danhgia.js') }}"></script>
<script src="{{ asset('js/luu.js') }}"></script>
<script src="{{ asset('js/xoa.js') }}"></script>

@include('partials.danhsach-danhgia')

@include('partials.danhsach-nguoilike')

</body>
</html>
