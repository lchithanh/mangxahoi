<li class="nav-item dropdown">
    @php
        $thongbaos = \App\Models\ThongBao::where('nguoi_dung_id', session('nguoi_dung_id'))
                        ->orderByDesc('thoi_gian')
                        ->take(5)
                        ->get();
        $unreadCount = \App\Models\ThongBao::where('nguoi_dung_id', session('nguoi_dung_id'))
                        ->where('da_xem', 0)
                        ->count();
    @endphp
    <a class="nav-link dropdown-toggle position-relative" href="#" id="notificationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="bi bi-bell"></i>
        @if($unreadCount > 0)
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                {{ $unreadCount }}
            </span>
        @endif
    </a>
    <ul class="dropdown-menu dropdown-menu-end p-2" aria-labelledby="notificationDropdown" style="min-width:300px;">
        @forelse($thongbaos as $tb)
            <li>
                <a href="#" class="dropdown-item notification-item {{ $tb->da_xem ? '' : 'fw-bold' }}" data-id="{{ $tb->thong_bao_id }}">
                    {{ $tb->noi_dung }}
                    <br><small class="text-muted">{{ $tb->thoi_gian->diffForHumans() }}</small>
                </a>
            </li>
        @empty
            <li class="dropdown-item text-center text-muted">Không có thông báo</li>
        @endforelse
    </ul>
</li>
<script>
document.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function(e){
        e.preventDefault();
        let id = this.dataset.id;

        fetch(`/thongbao/read/${id}`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json',
            },
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                window.location.href = data.link || '#';
            }
        })
        .catch(err => console.log(err));
    });
});
</script>
