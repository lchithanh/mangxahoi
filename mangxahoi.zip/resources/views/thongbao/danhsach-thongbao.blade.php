@extends('layout.master')

@section('content')
<div class="container">
    <h3>Thông báo của bạn</h3>

    <ul class="list-group" id="notification-list">
        @forelse($thongbaos as $tb)
            <li class="list-group-item {{ $tb->da_xem ? '' : 'fw-bold' }}"
                onclick="readNotification({{ $tb->id }})">
                <a href="{{ $tb->link ?? '#' }}">{{ $tb->noi_dung }}</a>
                <br>
                <small class="text-muted">{{ \Carbon\Carbon::parse($tb->thoi_gian)->diffForHumans() }}</small>
            </li>
        @empty
            <li class="list-group-item text-center text-muted">Bạn chưa có thông báo nào</li>
        @endforelse
    </ul>
</div>
@endsection
