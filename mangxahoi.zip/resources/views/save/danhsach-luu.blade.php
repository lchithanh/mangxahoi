@extends('layout.master')

@section('title', 'Bài viết đã lưu')

@section('content')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="container mt-4">

    <h3 class="mb-4 text-primary fw-bold">📌 Bài viết đã lưu</h3>

    {{-- Include posts, truyền đúng dữ liệu --}}
    @include('baiviet.danhsach-baiviet', [
        'baiviets' => $luuBaiViets,
        'currentUserId' => $currentUserId
    ])

    {{-- Phân trang --}}
    <div class="d-flex justify-content-center mt-3">
        {{ $luuBaiViets->links() }}
    </div>

</div>

@endsection


@section('scripts')
<script src="{{ asset('js/binhluan.js') }}"></script>
@endsection

