<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hồ sơ cá nhân</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f6fa;
}

/* Card profile cột trái */
.profile-card {
    border-radius: 20px;
    background-color: #fff;
    box-shadow: 0 8px 24px rgba(0,0,0,0.08);
    padding: 25px 20px;
    text-align: center;
    transition: transform 0.25s, box-shadow 0.25s;
}
.profile-card:hover { 
    transform: translateY(-4px); 
    box-shadow: 0 14px 32px rgba(0,0,0,0.12);
}

/* Avatar */
.avatar-hover:hover { transform: scale(1.1); transition: transform 0.2s; }

/* Nút profile */
.btn-profile-action {
    border-radius: 50px;
    padding: 8px 16px;
    font-weight:500;
    margin-bottom: 8px;
    transition: all 0.2s;
}
.btn-profile-action:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

/* Cột bài viết */
.post-card { 
    margin-bottom: 25px; 
    border-radius:15px; 
    box-shadow:0 4px 12px rgba(0,0,0,0.08); 
    transition: transform 0.2s;
}
.post-card:hover { transform: translateY(-2px); }

.post-header { display:flex; align-items:center; margin-bottom:10px; }
.post-header img { margin-right:12px; border-radius:50%; width:50px; height:50px; object-fit:cover; }
.post-header .user-name { font-weight:600; text-decoration:none; color:#212529; }
.post-header .badge-topic { font-size:0.8rem; margin-left:auto; }

/* Nội dung bài viết */
.post-content { margin-bottom:12px; line-height:1.5; }
.post-image { max-height:400px; object-fit:cover; border-radius:12px; margin-bottom:12px; }

/* Like button */
.btn-like { border:none; background:none; cursor:pointer; font-size:1.1rem; }
.btn-like.liked { color:#e0245e; font-weight:bold; }

/* Bình luận */
.comment-section { margin-top:10px; }
.comment { background-color:#f8f9fa; padding:8px; border-radius:10px; margin-bottom:8px; }
.comment-reply { background-color:#e9ecef; padding:6px 8px; border-radius:10px; margin-left:20px; margin-top:4px; font-size:0.9rem; }

</style>
</head>
<body>

<div class="container py-4">
    <div class="row g-4">

        <!-- Cột trái: thông tin cá nhân -->
        <div class="col-md-4">
            <div class="card profile-card">

                <!-- Avatar với viền gradient -->
                <div class="mx-auto mb-3" style="width:150px; height:150px; border-radius:50%; 
                     background: linear-gradient(135deg,#6c5ce7,#00b894); padding:3px;">
                    <img src="{{ $nguoiDung->anh_dai_dien ? asset('storage/' . $nguoiDung->anh_dai_dien) : 'https://via.placeholder.com/150' }}" 
                         alt="Avatar" class="img-fluid rounded-circle w-100 h-100 avatar-hover">
                </div>

                <!-- Tên & thông tin -->
                <h4 class="fw-bold mb-1 text-dark">{{ $nguoiDung->ho_va_ten ?? $nguoiDung->ten_dang_nhap }}</h4>
                <p class="text-muted mb-1">{{ $nguoiDung->ten_dang_nhap }}</p>
                <p class="text-muted mb-3" style="font-size:0.9rem;">{{ $nguoiDung->email ?? '-' }}</p>

                <!-- Nút hành động -->
                @if($isOwner)
                    <a href="{{ route('profile.setup') }}" class="btn btn-outline-primary btn-profile-action w-75 mb-2">
                        ✏️ Chỉnh sửa thông tin
                    </a>
                    <div class="d-flex justify-content-center gap-2 mt-2">
                        <form action="{{ route('logout') }}" method="POST">@csrf
                            <button class="btn btn-outline-danger btn-profile-action flex-fill">Đăng xuất</button>
                        </form>
                        <a href="{{ route('home') }}" class="btn btn-outline-success btn-profile-action flex-fill">Trang chủ</a>
                    </div>
                @else
                    <div class="d-grid gap-2">
                        <button class="btn btn-success btn-profile-action">➕ Theo dõi</button>
                        <button class="btn btn-primary btn-profile-action">✉️ Nhắn tin</button>
                        <a href="{{ route('home') }}" class="btn btn-outline-secondary btn-profile-action">← Quay lại</a>
                    </div>
                @endif

                <!-- Footer card: số bài viết / follower -->
                <div class="d-flex justify-content-between mt-4 pt-3 border-top" style="font-size:0.9rem;">
                    <div>
                        <span class="fw-bold">{{ $nguoiDung->baiviets->count() ?? 0 }}</span> Bài viết
                    </div>
                   
                </div>
            </div>
        </div>

        <!-- Cột phải: bài viết -->
        
        <div class="col-md-8">
    <h3 class="mb-4 text-primary fw-bold">
        {{ $isOwner ? 'Bài viết của bạn' : 'Bài viết của ' . ($nguoiDung->ho_va_ten ?? 'Người dùng') }}
    </h3>

    {{-- Gọi posts --}}
    @include('baiviet.danhsach-baiviet', [
    'baiviets' => $nguoiDung->baiviets, // bài viết của profile này
    'currentUserId' => session('nguoi_dung_id'), // id người đang đăng nhập
    'isOwner' => $isOwner // biến xác định xem profile có phải của chính mình
])
        </div>  

</div>

</body>
<!-- Sau khi include các partial posts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Các file JS custom nếu có -->
<script src="{{ asset('js/binhluan.js') }}"></script>
<script src="{{ asset('js/thich.js') }}"></script>
<script src="{{ asset('js/danhgia.js') }}"></script>
<script src="{{ asset('js/luu.js') }}"></script>
<script src="{{ asset('js/xoa.js') }}"></script>

</html>
