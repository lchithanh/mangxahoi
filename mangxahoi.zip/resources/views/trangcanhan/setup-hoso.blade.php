@extends('layout.master')

@section('title', 'Hoàn thiện hồ sơ')

@section('content')
<div class="container py-4">
    <div class="row">
        <!-- Cột trái: hồ sơ cá nhân -->
        <div class="col-md-4">
            <h2>Hoàn thiện hồ sơ</h2>
            <form action="{{ route('profile.setup.update') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <!-- Ảnh đại diện -->
                <div class="mb-3 text-center">
                    @if($nguoiDung->anh_dai_dien)
                        <img src="{{ asset('storage/' . $nguoiDung->anh_dai_dien) }}" 
                             class="img-fluid rounded-circle mb-2" style="width:150px; height:150px; object-fit:cover;">
                    @else
                        <img src="https://via.placeholder.com/150" 
                             class="img-fluid rounded-circle mb-2" style="width:150px; height:150px; object-fit:cover;">
                    @endif
                    <input type="file" class="form-control mt-2" name="anh_dai_dien" accept="image/*">
                </div>

                <div class="mb-3">
                    <label class="form-label">Họ và tên</label>
                    <input type="text" class="form-control" name="ho_va_ten" value="{{ old('ho_va_ten', $nguoiDung->ho_va_ten) }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="{{ old('email', $nguoiDung->email) }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ngày sinh</label>
                    <input type="date" class="form-control" name="ngay_sinh" value="{{ old('ngay_sinh', $nguoiDung->ngay_sinh) }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Địa chỉ</label>
                    <input type="text" class="form-control" name="dia_chi" value="{{ old('dia_chi', $nguoiDung->dia_chi) }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" class="form-control" name="sdt" value="{{ old('sdt', $nguoiDung->sdt) }}">
                </div>

                <button type="submit" class="btn btn-primary w-100">Cập nhật hồ sơ</button>
            </form>
        </div>

        <!-- Cột phải: danh sách bài viết -->
        <div class="col-md-8">
            <h3>Bài viết của bạn</h3>
            @forelse($nguoiDung->baiviets as $bv)
                <div class="card mb-4 shadow-sm border-0">
                    <div class="card-body">
                        <p class="mb-3">{{ $bv->noi_dung }}</p>

                        @if(!empty($bv->chude))
                            <span class="badge bg-info text-dark">{{ $bv->chude }}</span>
                        @endif

                        @if ($bv->duong_dan_hinh_anh)
                            <div class="mt-3 text-center">
                                <img src="{{ asset('storage/' . $bv->duong_dan_hinh_anh) }}"
                                     style="max-width:100%; border-radius:10px;">
                            </div>
                        @endif

                        <div class="d-flex justify-content-between mt-3">
                            <div>
                                <button class="btn btn-outline-danger btn-sm">❤️ Thích</button>
                                <button class="btn btn-outline-secondary btn-sm">💬 Bình luận</button>
                            </div>
                            <small class="text-muted">🕒 {{ $bv->created_at->format('H:i d/m/Y') }}</small>
                        </div>
                    </div>
                </div>
            @empty
                <p class="text-muted">Bạn chưa có bài viết nào.</p>
            @endforelse
        </div>
    </div>
</div>
@endsection
