@extends('layout.master')

@section('title', $chude->ten_chude)

@section('content')

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
.avatar-hover:hover { transform: scale(1.1); transition: transform 0.2s ease-in-out; }
.name-hover:hover { text-decoration: underline; transition: text-decoration 0.2s ease-in-out; }
.dropdown-toggle::after { display: none; }
.btn-like { border: none; background: none; cursor: pointer; font-size: 1.1rem; }
.btn-like.liked { color: #e0245e; font-weight: bold; }
</style>

<div class="container mt-4">
    <h3 class="mb-4 text-primary fw-bold">#{{ $chude->ten_chude }}</h3>

    {{-- Include partial posts, truyền dữ liệu bài viết --}}
    @include('baiviet.danhsach-baiviet', ['baiviets' => $baiviets])

    {{-- Phân trang --}}
    <div class="d-flex justify-content-center mt-3">
        {{ $baiviets->links() }}
    </div>
</div>



@endsection
