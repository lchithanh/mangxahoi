<?php

use Illuminate\Support\Facades\Route;

// Controllers
use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\SaveController;
use App\Http\Controllers\DanhGiaController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ChuDeController;
use App\Http\Controllers\Notification;


// ==========================
// TRANG CHỦ
// ==========================
Route::get('/', [PostController::class, 'index'])->name('home');


// ==========================
// AUTH
// ==========================
Route::get('/register', [RegisterController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register'])->name('register.submit');

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');


// ==========================
// PROFILE
// ==========================
Route::get('/profile/setup', [ProfileController::class, 'setup'])->name('profile.setup');
Route::post('/profile/setup', [ProfileController::class, 'updateProfile'])->name('profile.setup.update');
Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');
Route::get('/profile/{id}', [ProfileController::class, 'show'])->name('profile.view');


// ==========================
// BÀI VIẾT
// ==========================
Route::prefix('posts')->group(function () {

    // CRUD bài viết
    Route::get('/', [PostController::class, 'index'])->name('posts.index');
    Route::get('/create', [PostController::class, 'create'])->name('posts.create');
    Route::post('/', [PostController::class, 'store'])->name('posts.store');

    // 🔥 Route show — BẮT BUỘC CÓ
    Route::get('/{id}', [PostController::class, 'show'])->name('posts.show');

    Route::get('/{id}/edit', [PostController::class, 'edit'])->name('posts.edit');
    Route::put('/{id}', [PostController::class, 'update'])->name('posts.update');
    Route::delete('/{id}', [PostController::class, 'destroy'])->name('posts.destroy');


    // ==========================
    // COMMENT — tối ưu chuẩn REST
    // ==========================

    // Thêm bình luận vào bài viết
    Route::post('/{postId}/comments', [CommentController::class, 'store'])
        ->name('comments.store');

    // Lấy toàn bộ comment của bài viết
    Route::get('/{postId}/comments', [CommentController::class, 'listComments'])
        ->name('comments.index');

    // Sửa bình luận
    Route::put('/comments/{id}', [CommentController::class, 'update'])
        ->name('comments.update');

    // Xóa bình luận
    Route::delete('/comments/{id}', [CommentController::class, 'destroy'])
        ->name('comments.destroy');
        


    // ==========================
    // LIKE
    // ==========================
    Route::post('/{id}/like', [LikeController::class, 'toggle'])->name('posts.like');
    Route::get('/{id}/likers', [LikeController::class, 'getLikers'])->name('posts.likers');


    // ==========================
    // SAVE BÀI VIẾT
    // ==========================
    Route::post('/{id}/save', [SaveController::class, 'toggle'])->name('posts.save');
    Route::delete('/{id}/save', [SaveController::class, 'destroy'])->name('posts.save.destroy');


    // ==========================
    // RATING
    // ==========================
    Route::put('/{id}/rate', [DanhGiaController::class, 'update'])->name('posts.rate');
    Route::get('/{id}/raters', [DanhGiaController::class, 'getRaters'])->name('posts.raters');

});


// ==========================
// BÀI VIẾT ĐÃ LƯU
// ==========================
Route::get('/saved-posts', [SaveController::class, 'index'])->name('save.index');


// ==========================
// CHỦ ĐỀ
// ==========================
Route::get('/chude/{id}', [ChuDeController::class, 'show'])->name('chude.show');


// ==========================
// THÔNG BÁO
// ==========================
Route::get('/thongbao', [Notification::class, 'index'])->name('thongbao.list');
Route::get('/thongbao/new', [Notification::class, 'getNew'])->name('thongbao.new');
